# AI Learning Quiz (Flutter)

A Dart/Flutter rewrite of the Tkinter quiz app — same flow: name entry,
main menu, CBT practice (timer, questions, navigation, calculator,
in-app AI assistant), and a results screen.

This project has Dart source code and a question bank, but **no
`android/` folder yet** — that gets generated automatically the first
time it's built (see below), so you don't need Android Studio.

## Files
- `lib/main.dart` — app entry point
- `lib/screens/` — welcome, menu, CBT menu, time select, quiz, results, AI assistant
- `lib/widgets/` — shared button style, calculator popup
- `lib/models/question.dart` — question data shape
- `assets/questions.json` — sample question bank (swap in your own, same format)
- `.github/workflows/build_apk.yml` — builds a real `.apk` automatically

## Option A: Build with GitHub Actions (recommended, entirely from your phone)
1. Create a free GitHub account if you don't have one.
2. Create a new repository (e.g. `ai-learning-quiz`).
3. Upload every file/folder from this project into that repository,
   keeping the same folder structure (the GitHub web uploader lets you
   drag in a whole folder, or you can add files one by one).
4. Once everything is pushed to the `main` branch, go to the
   **Actions** tab of your repo — a "Build APK" workflow will run
   automatically.
5. When it finishes (a few minutes), open that workflow run and
   download the **app-release-apk** artifact — that's your installable
   APK.
6. Transfer/download it to your phone and tap it to install (you may
   need to allow "install unknown apps" for your browser/file manager
   the first time).

## Option B: Build with FlutLab.io (browser IDE, also phone-friendly)
1. Go to flutlab.io and create a free account.
2. Create a new Flutter project.
3. Copy the contents of `lib/`, `assets/`, and `pubspec.yaml` into the
   FlutLab project (matching the same file paths).
4. Use FlutLab's "Build APK" option to compile and download the APK
   directly.

## Editing the questions
Add more entries to `assets/questions.json`, following the same shape:

```json
{
  "text": "Your question?",
  "A": "Option A",
  "B": "Option B",
  "C": "Option C",
  "D": "Option D",
  "answer": "A",
  "explanation": "Why A is correct."
}
```

## Notes
- This was written and reviewed carefully but not compiled locally
  (no Flutter SDK available in the environment that generated it) —
  if the GitHub Actions build reports an error, share the log and it
  can be fixed directly.
- The AI Assistant screens are prototypes (echo the question back)
  just like the original Python version — wire up a real API call
  when you're ready.
