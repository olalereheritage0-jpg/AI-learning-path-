import 'package:flutter/material.dart';

class AiAssistantScreen extends StatefulWidget {
  const AiAssistantScreen({super.key});

  @override
  State<AiAssistantScreen> createState() => _AiAssistantScreenState();
}

class _AiAssistantScreenState extends State<AiAssistantScreen> {
  final TextEditingController _controller = TextEditingController();
  String _response = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _send() {
    final message = _controller.text.trim();
    if (message.isEmpty) {
      setState(() => _response = 'Please type something first');
      return;
    }
    setState(() {
      _response = 'You asked:\n$message\n\nAI Assistant prototype is working!';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Assistant')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text('What would you like help with?'),
            const SizedBox(height: 10),
            TextField(controller: _controller),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: _send, child: const Text('Send')),
            const SizedBox(height: 20),
            Text(_response),
          ],
        ),
      ),
    );
  }
}
