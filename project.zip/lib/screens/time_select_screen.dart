import 'package:flutter/material.dart';
import 'quiz_screen.dart';

class TimeSelectScreen extends StatefulWidget {
  const TimeSelectScreen({super.key});

  @override
  State<TimeSelectScreen> createState() => _TimeSelectScreenState();
}

class _TimeSelectScreenState extends State<TimeSelectScreen> {
  String _selectedMinutes = '2';
  final List<String> _options = ['2', '5', '10', '20', '30', '60'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CBT Practice')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Choose Practice Time',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text('Select how long you want to practice:'),
            const SizedBox(height: 12),
            DropdownButton<String>(
              value: _selectedMinutes,
              items: _options
                  .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                  .toList(),
              onChanged: (value) {
                if (value != null) setState(() => _selectedMinutes = value);
              },
            ),
            const Text('minutes'),
            const SizedBox(height: 24),
            SizedBox(
              width: 220,
              height: 48,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (_) =>
                          QuizScreen(totalMinutes: int.parse(_selectedMinutes)),
                    ),
                  );
                },
                child: const Text('Start Practice'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: 220,
              height: 48,
              child: OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('← Back'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
