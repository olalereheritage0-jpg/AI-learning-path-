import 'package:flutter/material.dart';
import 'cbt_menu_screen.dart';
import 'ai_assistant_screen.dart';

class MenuScreen extends StatelessWidget {
  final String firstName;
  const MenuScreen({super.key, required this.firstName});

  void _comingSoon(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Coming Soon'),
        content: const Text('This feature is not available yet.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Widget _menuButton(String label, VoidCallback onTap) {
    return SizedBox(
      width: 160,
      height: 100,
      child: ElevatedButton(
        onPressed: onTap,
        child: Text(label, textAlign: TextAlign.center),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const SizedBox(height: 8),
              Text(
                'Welcome, $firstName',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.center,
                children: [
                  _menuButton('CBT Practice', () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CbtMenuScreen()),
                    );
                  }),
                  _menuButton('AI Assistant', () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AiAssistantScreen()),
                    );
                  }),
                  _menuButton('Question Manager', () => _comingSoon(context)),
                  _menuButton('Meeting', () => _comingSoon(context)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
