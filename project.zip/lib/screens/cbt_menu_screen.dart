import 'package:flutter/material.dart';
import 'time_select_screen.dart';

class CbtMenuScreen extends StatelessWidget {
  const CbtMenuScreen({super.key});

  void _examComingSoon(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Exam Mode'),
        content: const Text('Exam Mode Coming Soon'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CBT Practice')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 220,
              height: 48,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const TimeSelectScreen()),
                  );
                },
                child: const Text('Practice Mode'),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: 220,
              height: 48,
              child: ElevatedButton(
                onPressed: () => _examComingSoon(context),
                child: const Text('Exam Mode'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
