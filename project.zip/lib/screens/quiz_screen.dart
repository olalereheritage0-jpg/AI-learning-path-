import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/question.dart';
import '../theme/app_colors.dart';
import '../widgets/app_button.dart';
import '../widgets/calculator_dialog.dart';
import 'results_screen.dart';

class QuizScreen extends StatefulWidget {
  final int totalMinutes;
  const QuizScreen({super.key, required this.totalMinutes});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  List<Question> _questions = [];
  bool _loading = true;
  String? _loadError;

  int _currentQuestion = 0;
  List<String?> _userAnswers = [];
  late int _timeLeft;
  Timer? _timer;
  bool _quizSubmitted = false;
  bool _quizPaused = false;
  bool _aiOpen = false;
  String? _selectedOption;
  String? _feedbackText;
  bool? _feedbackCorrect;
  final TextEditingController _aiController = TextEditingController();
  String _aiResponse = '';

  @override
  void initState() {
    super.initState();
    _timeLeft = widget.totalMinutes * 60;
    _loadQuestions();
  }

  Future<void> _loadQuestions() async {
    try {
      final raw =
          await DefaultAssetBundle.of(context).loadString('assets/questions.json');
      final data = jsonDecode(raw) as List<dynamic>;
      setState(() {
        _questions =
            data.map((q) => Question.fromJson(q as Map<String, dynamic>)).toList();
        _userAnswers = List<String?>.filled(_questions.length, null);
        _loading = false;
      });
      _startTimer();
    } catch (e) {
      setState(() {
        _loadError = 'Could not load questions.json\n\n$e';
        _loading = false;
      });
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_quizPaused || _quizSubmitted) return;
      if (_timeLeft > 0) {
        setState(() => _timeLeft--);
      } else {
        _submitQuiz(automatic: true);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _aiController.dispose();
    super.dispose();
  }

  void _togglePause() {
    if (_quizSubmitted) return;
    setState(() => _quizPaused = !_quizPaused);
  }

  void _selectOption(String letter) {
    if (_quizPaused || _quizSubmitted) return;
    final question = _questions[_currentQuestion];
    setState(() {
      _userAnswers[_currentQuestion] = letter;
      _selectedOption = letter;
      _feedbackCorrect = letter == question.answer;
      _feedbackText = question.explanation;
    });
  }

  void _showQuestion(int index) {
    setState(() {
      _currentQuestion = index;
      _selectedOption = _userAnswers[index];
      if (_selectedOption != null) {
        final question = _questions[index];
        _feedbackCorrect = _selectedOption == question.answer;
        _feedbackText = question.explanation;
      } else {
        _feedbackText = null;
        _feedbackCorrect = null;
      }
    });
  }

  void _previousQuestion() {
    if (_currentQuestion > 0) _showQuestion(_currentQuestion - 1);
  }

  void _nextQuestion() {
    if (_currentQuestion < _questions.length - 1) _showQuestion(_currentQuestion + 1);
  }

  Future<void> _submitQuiz({bool automatic = false}) async {
    if (_quizSubmitted) return;

    if (!automatic) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Submit Quiz'),
          content: const Text('Are you sure you want to submit your answers?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Yes'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
    }

    int score = 0;
    for (int i = 0; i < _questions.length; i++) {
      if (_userAnswers[i] == _questions[i].answer) score++;
    }

    setState(() => _quizSubmitted = true);
    _timer?.cancel();

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ResultsScreen(score: score, total: _questions.length),
      ),
    );
  }

  Future<void> _backToCbtMenu() async {
    if (_quizSubmitted) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Leave Practice'),
        content: const Text('Are you sure you want to leave this practice session?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Yes'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      Navigator.of(context).pop();
    }
  }

  void _askAiAboutQuestion() {
    final question = _questions[_currentQuestion];
    setState(() {
      _quizPaused = true;
      _aiOpen = true;
      _aiController.text = 'Please explain this question: ${question.text}';
      _aiResponse = '';
    });
  }

  void _closeAiOverlay() {
    setState(() {
      _aiOpen = false;
      _quizPaused = false;
    });
  }

  void _sendAiMessage() {
    final message = _aiController.text.trim();
    if (message.isEmpty) {
      setState(() => _aiResponse = 'Please type something first');
      return;
    }
    setState(() {
      _aiResponse = 'You asked:\n$message\n\nAI Assistant prototype is working!';
    });
  }

  String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_loadError != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Error')),
        body: Padding(padding: const EdgeInsets.all(16), child: Text(_loadError!)),
      );
    }

    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('No Questions')),
        body: const Center(
          child: Text('No questions are available.\nPlease check questions.json'),
        ),
      );
    }

    final question = _questions[_currentQuestion];
    final isLastQuestion = _currentQuestion == _questions.length - 1;
    final size = MediaQuery.of(context).size;
    final isLandscape = size.width > size.height * 1.2;
    final enabledNav = !_quizPaused && !_quizSubmitted;

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                _buildHeader(isLandscape),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          question.text,
                          style: TextStyle(fontSize: isLandscape ? 15 : 17),
                        ),
                        const SizedBox(height: 10),
                        for (final letter in ['A', 'B', 'C', 'D'])
                          _buildOption(letter, question.optionFor(letter)),
                        if (_feedbackText != null) _buildFeedback(),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: AppButton(
                    text: '🖩 Calculator',
                    bg: AppColors.calcBg,
                    fg: AppColors.calcBorder,
                    border: AppColors.calcBorder,
                    onTap: () =>
                        showDialog(context: context, builder: (_) => const CalculatorDialog()),
                  ),
                ),
                _buildNavigationBar(isLastQuestion, isLandscape, enabledNav),
              ],
            ),
            if (_aiOpen) _buildAiOverlay(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(bool isLandscape) {
    final fontSize = isLandscape ? 11.0 : 13.0;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.black12),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Time Left: ${_formatTime(_timeLeft)}',
              style: TextStyle(
                color: AppColors.errorRed,
                fontWeight: FontWeight.bold,
                fontSize: fontSize,
              ),
            ),
          ),
          AppButton(
            text: _quizPaused ? 'Resume' : 'Pause',
            bg: AppColors.pauseYellowBg,
            fg: AppColors.pauseYellowFg,
            border: AppColors.pauseYellowBorder,
            onTap: _togglePause,
            fontSize: fontSize,
          ),
          const SizedBox(width: 8),
          Text(
            'Question ${_currentQuestion + 1} of ${_questions.length}',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: fontSize),
          ),
        ],
      ),
    );
  }

  Widget _buildOption(String letter, String text) {
    final isSelected = _selectedOption == letter;
    return GestureDetector(
      onTap: () => _selectOption(letter),
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.correctGreenBg : Colors.white,
          border: Border.all(color: Colors.black12),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isSelected ? '●' : '○',
              style: TextStyle(
                fontSize: 18,
                color: isSelected ? AppColors.correctGreenFg : Colors.black,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text('$letter. $text', style: const TextStyle(fontSize: 14)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeedback() {
    final correct = _feedbackCorrect == true;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(border: Border.all(color: Colors.black26)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            correct ? '✓ CORRECT' : '✗ INCORRECT',
            style: TextStyle(
              color: correct ? Colors.green : Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 8),
          Text('Explanation:\n$_feedbackText'),
          const SizedBox(height: 10),
          AppButton(
            text: 'Ask AI to Explain',
            bg: AppColors.nextBlue,
            fg: Colors.white,
            onTap: _askAiAboutQuestion,
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationBar(bool isLastQuestion, bool isLandscape, bool enabledNav) {
    final barHeight = isLandscape ? 42.0 : 52.0;
    return Container(
      height: barHeight,
      margin: const EdgeInsets.fromLTRB(8, 4, 8, 8),
      decoration: BoxDecoration(border: Border.all(color: Colors.black12)),
      child: Row(
        children: [
          Expanded(
            child: AppButton(
              text: '← Back',
              bg: AppColors.backGrayBg,
              fg: AppColors.backGrayFg,
              border: AppColors.backGrayBorder,
              onTap: _backToCbtMenu,
              margin: const EdgeInsets.all(4),
            ),
          ),
          Expanded(
            child: AppButton(
              text: 'Previous',
              bg: AppColors.backGrayBg,
              fg: AppColors.backGrayFg,
              border: AppColors.backGrayBorder,
              onTap: enabledNav ? _previousQuestion : null,
              margin: const EdgeInsets.all(4),
            ),
          ),
          Expanded(
            child: isLastQuestion
                ? AppButton(
                    text: 'Submit',
                    bg: AppColors.submitGreen,
                    fg: Colors.white,
                    onTap: () => _submitQuiz(),
                    margin: const EdgeInsets.all(4),
                  )
                : AppButton(
                    text: 'Next',
                    bg: AppColors.nextBlue,
                    fg: Colors.white,
                    onTap: enabledNav ? _nextQuestion : null,
                    margin: const EdgeInsets.all(4),
                  ),
          ),
          if (!isLastQuestion)
            Expanded(
              child: AppButton(
                text: 'Submit',
                bg: AppColors.submitGreen,
                fg: Colors.white,
                onTap: () => _submitQuiz(),
                margin: const EdgeInsets.all(4),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAiOverlay() {
    return Positioned.fill(
      child: Container(
        color: Colors.white,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text(
                  'AI Assistant',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                const Text('What would you like help with?'),
                const SizedBox(height: 10),
                TextField(controller: _aiController),
                const SizedBox(height: 10),
                AppButton(
                  text: 'Send',
                  bg: AppColors.nextBlue,
                  fg: Colors.white,
                  onTap: _sendAiMessage,
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: SingleChildScrollView(
                    child: Text(_aiResponse, textAlign: TextAlign.left),
                  ),
                ),
                AppButton(
                  text: '← Return to CBT',
                  bg: AppColors.backGrayBg,
                  fg: AppColors.backGrayFg,
                  border: AppColors.backGrayBorder,
                  onTap: _closeAiOverlay,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
