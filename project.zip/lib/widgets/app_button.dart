import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class AppButton extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  final Color? border;
  final VoidCallback? onTap;
  final double fontSize;
  final EdgeInsetsGeometry margin;

  const AppButton({
    super.key,
    required this.text,
    required this.bg,
    required this.fg,
    this.border,
    required this.onTap,
    this.fontSize = 14,
    this.margin = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        alignment: Alignment.center,
        margin: margin,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: enabled ? bg : AppColors.disabledBg,
          border: Border.all(
            color: enabled ? (border ?? Colors.black26) : AppColors.disabledBorder,
          ),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: enabled ? fg : AppColors.disabledFg,
            fontWeight: FontWeight.bold,
            fontSize: fontSize,
          ),
        ),
      ),
    );
  }
}
