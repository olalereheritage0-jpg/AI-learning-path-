import 'package:flutter/material.dart';

class CalculatorDialog extends StatefulWidget {
  const CalculatorDialog({super.key});

  @override
  State<CalculatorDialog> createState() => _CalculatorDialogState();
}

class _CalculatorDialogState extends State<CalculatorDialog> {
  String _display = '0';
  double? _firstOperand;
  String? _pendingOperator;
  bool _shouldResetDisplay = false;

  void _inputDigit(String digit) {
    setState(() {
      if (_display == '0' || _shouldResetDisplay) {
        _display = digit;
        _shouldResetDisplay = false;
      } else {
        _display += digit;
      }
    });
  }

  void _inputDecimal() {
    setState(() {
      if (_shouldResetDisplay) {
        _display = '0.';
        _shouldResetDisplay = false;
      } else if (!_display.contains('.')) {
        _display += '.';
      }
    });
  }

  void _chooseOperator(String operator) {
    setState(() {
      _firstOperand = double.tryParse(_display);
      _pendingOperator = operator;
      _shouldResetDisplay = true;
    });
  }

  void _calculate() {
    if (_firstOperand == null || _pendingOperator == null) return;
    final second = double.tryParse(_display) ?? 0;
    double result;

    switch (_pendingOperator) {
      case '+':
        result = _firstOperand! + second;
        break;
      case '-':
        result = _firstOperand! - second;
        break;
      case '×':
        result = _firstOperand! * second;
        break;
      case '÷':
        result = second == 0 ? double.nan : _firstOperand! / second;
        break;
      default:
        result = second;
    }

    setState(() {
      _display = _formatResult(result);
      _firstOperand = null;
      _pendingOperator = null;
      _shouldResetDisplay = true;
    });
  }

  String _formatResult(double value) {
    if (value.isNaN) return 'Error';
    if (value == value.roundToDouble()) return value.toInt().toString();
    return value.toString();
  }

  void _clear() {
    setState(() {
      _display = '0';
      _firstOperand = null;
      _pendingOperator = null;
      _shouldResetDisplay = false;
    });
  }

  Widget _button(String label, {VoidCallback? onTap, Color? bg}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: bg,
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          onPressed: onTap,
          child: Text(label, style: const TextStyle(fontSize: 18)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: SizedBox(
          width: 300,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.all(16),
                child: Text(_display, style: const TextStyle(fontSize: 28)),
              ),
              Row(children: [
                _button('C', onTap: _clear, bg: Colors.redAccent.shade100),
                _button('÷', onTap: () => _chooseOperator('÷')),
                _button('×', onTap: () => _chooseOperator('×')),
              ]),
              Row(children: [
                _button('7', onTap: () => _inputDigit('7')),
                _button('8', onTap: () => _inputDigit('8')),
                _button('9', onTap: () => _inputDigit('9')),
              ]),
              Row(children: [
                _button('4', onTap: () => _inputDigit('4')),
                _button('5', onTap: () => _inputDigit('5')),
                _button('6', onTap: () => _inputDigit('6')),
              ]),
              Row(children: [
                _button('1', onTap: () => _inputDigit('1')),
                _button('2', onTap: () => _inputDigit('2')),
                _button('3', onTap: () => _inputDigit('3')),
              ]),
              Row(children: [
                _button('0', onTap: () => _inputDigit('0')),
                _button('.', onTap: _inputDecimal),
                _button('=', onTap: _calculate, bg: Colors.blue.shade100),
              ]),
              Row(children: [
                _button('-', onTap: () => _chooseOperator('-')),
                _button('+', onTap: () => _chooseOperator('+')),
                _button('Close', onTap: () => Navigator.of(context).pop()),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
