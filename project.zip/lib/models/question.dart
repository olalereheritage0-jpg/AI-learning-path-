class Question {
  final String text;
  final String optionA;
  final String optionB;
  final String optionC;
  final String optionD;
  final String answer;
  final String explanation;

  Question({
    required this.text,
    required this.optionA,
    required this.optionB,
    required this.optionC,
    required this.optionD,
    required this.answer,
    required this.explanation,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      text: json['text'] ?? 'No question text',
      optionA: json['A'] ?? '',
      optionB: json['B'] ?? '',
      optionC: json['C'] ?? '',
      optionD: json['D'] ?? '',
      answer: json['answer'] ?? '',
      explanation: json['explanation'] ?? 'No explanation available.',
    );
  }

  String optionFor(String letter) {
    switch (letter) {
      case 'A':
        return optionA;
      case 'B':
        return optionB;
      case 'C':
        return optionC;
      case 'D':
        return optionD;
      default:
        return '';
    }
  }
}
