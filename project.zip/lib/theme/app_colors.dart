import 'package:flutter/material.dart';

class AppColors {
  static const pauseYellowBg = Color(0xFFFFF8E7);
  static const pauseYellowFg = Color(0xFFC77A00);
  static const pauseYellowBorder = Color(0xFFF2CB6B);

  static const backGrayBg = Color(0xFFF2F2F2);
  static const backGrayFg = Color(0xFF333333);
  static const backGrayBorder = Color(0xFFD0D0D0);

  static const nextBlue = Color(0xFF2F6FED);
  static const submitGreen = Color(0xFF27AE60);

  static const calcBg = Color(0xFFEAF2FF);
  static const calcBorder = Color(0xFF2D5FDB);

  static const correctGreenBg = Color(0xFFE8F5E9);
  static const correctGreenFg = Color(0xFF22A447);

  static const errorRed = Color(0xFFD71920);

  static const disabledBg = Color(0xFFE8E8E8);
  static const disabledFg = Color(0xFFAAAAAA);
  static const disabledBorder = Color(0xFFCCCCCC);
}
